<?php
$arquivo = __DIR__ . '/Site/DADOS/tarefas.json'; // onde as informações são armazenadas

$tarefas = file_exists($arquivo) ? json_decode(file_get_contents($arquivo), true) : [];

$concluidas = 0;
$andamento = 0;
$hoje = 0;

$dataHoje = date('d-m-Y');

if (!empty($tarefas) && is_array($tarefas)) {
    foreach ($tarefas as $tarefa) {
        // tarefas concluídas
        if (isset($tarefa['concluida']) && $tarefa['concluida'] === true) {
            $concluidas++;
        }
        // tarefas em andamento
        elseif (isset($tarefa['concluida']) && $tarefa['concluida'] === false) {
            $andamento++;
        }

        
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <!-- Define a codificação de caracteres para o documento -->
    <meta charset="UTF-8" />
    <!-- Define configurações de visualização responsiva -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Título exibido na aba do navegador -->
    <title>Tarefy</title>
    <!-- Importa o arquivo CSS principal -->
    <link rel="stylesheet" href="/Site/CSS/main.css" />
    <!-- Ícone exibido na aba do navegador -->
    <link rel="icon" href="/Imagens/icone.svg" />
  </head>

  <body>
    <!-- Barra lateral esquerda (menu) -->
    <div id="sidebar" class="taskbar">
      <!-- Área de perfil, notificações e temas -->
      <div class="login">
        <!-- Link para a criação/edição da conta -->
        <div class="perfil" id="expandSidebar">
          <a href="/Site/HTML/create.html">
            <img id="perfilIcon" src="/Imagens/Perfil.svg" alt="Perfil" />
            <span>Conta</span>
          </a>
        </div>
        <!-- Link para página de notificações -->
        <div class="sino">
          <a href="/Site/HTML/notificacoes.html">
            <img src="/Imagens/Sino.svg" alt="Notificações" />
          </a>
        </div>
        <!-- Link para página de temas -->
        <div class="pincel" id="collapseSidebar">
          <a href="/Site/HTML/temas.html">
            <img id="pincelIcon" src="/Imagens/Pincel.svg" alt="Tema" />
          </a>
        </div>
      </div>

      <!-- Botão para adicionar nova tarefa -->
      <div class="addtask">
        <a href="index.php">
          <img src="/Imagens/Mais.svg" alt="Adicionar Tarefa" />
          <span>Adicionar Tarefa</span>
        </a>
      </div>

      <!-- Links principais para navegação -->
      <div class="buttons">
        <!-- Link para visualizar tarefas -->
        <div class="calendario">
          <a href="/Site/PHP/tarefas.php">
            <img src="/Imagens/Calendário.svg" alt="Minhas Tarefas" />
            <span>Minhas Tarefas</span>
          </a>
        </div>
        <!-- Link para visualizar tarefas concluídas -->
        <div class="concluido">
          <a href="/Site/PHP/concluidos.php">
            <img src="/Imagens/Concluido.svg" alt="Concluídas" />
            <span>Concluído</span>
          </a>
        </div>
      </div>

      <hr />

      <!-- Seção de opções adicionais -->
      <div class="more">
        <!-- Link para adicionar uma nova equipe -->
        <div class="equipe">
          <a href="/Site/HTML/equipe.html">
            <img src="/Imagens/Mais.svg" alt="Adicionar equipe" />
            <span>Adicionar equipe</span>
          </a>
        </div>
        <!-- Link para configurações do sistema -->
        <div class="suporte">
          <a href="/Site/HTML/config.html">
            <img src="/Imagens/config.svg" alt="Configurações" />
            <span>Configurações</span>
          </a>
        </div>
      </div>
    </div>

    <!-- Área principal do conteúdo -->
    <div class="conteudo">
      <!-- Logo principal -->
      <div class="logonot">
        <a href="index.php">
          <img src="/Imagens/logo.svg" alt="Logo" />
        </a>
      </div>

      <!-- Saudação inicial -->
      <h1 class="text-t">Seja bem-vindo! 👋</h1>

      <!-- Seção com frase motivacional e imagem -->
      <section class="status-dia">
        <p id="fraseMotivacional"></p> <!-- Frase gerada dinamicamente -->
        <div><img src="/Imagens/Mente.png" alt="Mind" /></div>
      </section>

      <!-- Seção inferior com resumo e botão para adicionar tarefa -->
      <div class="adicionar-final">
        <!-- Cards com resumo de tarefas -->
        <div class="cards-resumo">
          <div class="card">
            <span class="numero" id="atrasadas"><?php echo $andamento; ?></span>
            <span class="legenda">Em andamento</span>
          </div>
          <div class="card">
            <span class="numero" id="concluidas"><?php echo $concluidas; ?></span>
            <span class="legenda">Concluídas</span>
          </div>
        </div>

        <!-- Botão para abrir o formulário de tarefa -->
        <button id="toggleForm" class="summary-button">Adicionar tarefa</button>

        <!-- Formulário para adicionar tarefa (escondido por padrão) -->
        <div
          id="formContainer"
          class="formulario-container"
          style="height: 0; overflow: hidden"
        >
          <form action="/Site/PHP/salvar.php" method="post" class="formulario">
            <!-- Seleção de categoria -->
            <select id="Categoria" name="Categoria">
              <option>Trabalho</option>
              <option>Estudo</option>
              <option>Pessoal</option>
            </select>
            <!-- Campo de título -->
            <input type="text" placeholder="Título da tarefa" name="titulo" />
            <!-- Campo de descrição -->
            <textarea placeholder="Descrição..." name="descricao"></textarea>
            <!-- Campo de data/hora -->
            <input type="datetime-local" id="datetime" name="data" />
            <!-- Botão de envio -->
            <button class="botao-salvar" type="submit">Salvar tarefa</button>
          </form>
        </div>
      </div>
    </div>

    <!-- Script JavaScript para funcionalidades da página -->
    <script src="/Site/JS/scripts.js" defer></script>
  </body>
</html>