// Executa o código quando o conteúdo da página for completamente carregado
document.addEventListener('DOMContentLoaded', () => {

    /* ---------- Referências aos elementos do DOM ---------- */
    const sidebar = document.getElementById('sidebar');
    const expandSidebar = document.getElementById('expandSidebar');
    const collapseSidebar = document.getElementById('collapseSidebar');
    const perfilIcon = document.getElementById('perfilIcon');
    const pincelIcon = document.getElementById('pincelIcon'); // Corrigido para o ícone correto
    const toggleFormButton = document.getElementById('toggleForm');
    const formContainer = document.getElementById('formContainer');
    const fraseMotivacional = document.getElementById("fraseMotivacional");

    /* ---------- Estado inicial da interface ---------- */
    sidebar.classList.add('recolhido'); // Começa com a sidebar recolhida
    perfilIcon.src = "../../Imagens/Layout.svg"; // Ícone padrão do perfil
    pincelIcon.src = "../../Imagens/Pincel.svg";  // Ícone padrão do pincel

    /* ---------- Evento para expandir a sidebar ---------- */
    expandSidebar.addEventListener('click', e => {
        if (sidebar.classList.contains('recolhido')) {
            e.preventDefault(); // Impede comportamento padrão do botão
            sidebar.classList.remove('recolhido'); // Expande a sidebar
            perfilIcon.src = "../../Imagens/Perfil.svg"; // Altera o ícone
            pincelIcon.src = "../../Imagens/Layout.svg"; // Troca o ícone
        }
    });

    /* ---------- Evento para recolher a sidebar ---------- */
    collapseSidebar.addEventListener('click', e => {
        if (!sidebar.classList.contains('recolhido')) {
            e.preventDefault(); // Impede comportamento padrão do botão
            sidebar.classList.add('recolhido'); // Recolhe a sidebar
            perfilIcon.src = "../../Imagens/Layout.svg"; // Volta o ícone
            pincelIcon.src = "../../Imagens/Pincel.svg"; // Ícone original
        }
    });

    /* ---------- Função para trocar entre abas de notificação ---------- */
    window.selectTab = (el, id) => {
        // Remove a classe "active" de todas as abas
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        // Adiciona "active" na aba clicada
        el.classList.add('active');

        // Esconde todos os conteúdos
        document.querySelectorAll('.content').forEach(c => c.style.display = 'none');
        // Exibe apenas o conteúdo da aba ativa
        document.getElementById(id).style.display = 'block';
    };

    /* ---------- Lógica para abrir/fechar o formulário de adicionar tarefa ---------- */
    let formAberto = false; // Estado inicial do formulário (fechado)

    toggleFormButton.addEventListener('click', () => {
        if (formAberto) {
            // Fecha o formulário
            formContainer.style.height = '0';
            formContainer.style.overflow = 'hidden';
        } else {
            // Abre o formulário (ajusta altura com base no conteúdo)
            formContainer.style.height = formContainer.scrollHeight + 'px';
            formContainer.style.overflow = 'visible';
        }
        formAberto = !formAberto; // Inverte o estado
    });

    /* ---------- Exibição aleatória de frase motivacional ---------- */
    const frases = [
        "Você consegue terminar tudo antes do almoço!",
        "Cada tarefa concluída é XP para o seu ‘shape’ de produtividade 💪",
        "Respire fundo e comece pela mais simples."
    ];
    if (fraseMotivacional) {
        // Escolhe uma frase aleatória e exibe
        fraseMotivacional.textContent = frases[Math.floor(Math.random() * frases.length)];
    }

    /* ---------- Lógica para abrir formulário via parâmetro na URL ---------- */
    const urlParams = new URLSearchParams(window.location.search);
    const abrirFormulario = urlParams.get("abrirFormulario");

    if (abrirFormulario === "true") {
        if (toggleFormButton && formContainer) {
            toggleFormButton.click(); // Usa o botão de toggle para manter consistência
        }
    }

    // Aqui você pode adicionar lógica extra, como mostrar estatísticas com LocalStorage
});
