<?php
$arquivo = __DIR__ . '/../DADOS/tarefas.json'; // onde as informações são armazenadas

$id = $_GET['id'] ?? '';

$tarefas = json_decode(file_get_contents($arquivo), true);

foreach ($tarefas as &$tarefa) {
    if ($tarefa['id'] === $id) {
        $tarefa['concluida'] = !$tarefa['concluida'];
    }
}

file_put_contents($arquivo, json_encode($tarefas, JSON_PRETTY_PRINT));

header('Location: concluidos.php');
exit;
?>