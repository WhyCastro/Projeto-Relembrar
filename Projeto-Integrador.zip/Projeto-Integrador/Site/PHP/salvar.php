<?php
$arquivo = __DIR__ . '/../DADOS/tarefas.json'; // onde as informações são armazenadas

$categoria = $_POST['categoria'] ?? '';
$data = $_POST['data'] ?? '';
$titulo = $_POST['titulo'] ?? '';
$descricao = $_POST['descricao'] ?? '';

if ($titulo && $descricao) { //verifica se os campos foram preenchidos
    $tarefas = file_exists($arquivo) ? json_decode(file_get_contents($arquivo), true) : [];

    $tarefas[] = [
        'id' => uniqid(),
        'categoria' => $categoria,
        'data' => $data,
        'titulo' => $titulo,
        'descricao' => $descricao,
        'concluida' => false
    ];

    file_put_contents($arquivo, json_encode($tarefas, JSON_PRETTY_PRINT));

    header('Location: tarefas.php');
    exit;
} else {
    header('Location: erro.php'); //caso os campos não foram preenchidos, manda para a pág de erro
    exit;
}
?>