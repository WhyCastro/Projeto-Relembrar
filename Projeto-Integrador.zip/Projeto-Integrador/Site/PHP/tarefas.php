<?php
$arquivo = __DIR__ . '/../DADOS/tarefas.json'; // onde as informações são armazenadas

$tarefas = file_exists($arquivo) ? json_decode(file_get_contents($arquivo), true) : [];
?>

<!DOCTYPE html>
<html lang="pt-br"> <!-- Define o idioma da página como português do Brasil -->
  <head>
    <meta charset="UTF-8" /> <!-- Define a codificação de caracteres como UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <!-- Responsividade para dispositivos móveis -->
    <title>Tarefy</title> <!-- Título da aba do navegador -->
    <link rel="stylesheet" href="../CSS/main.css" /> <!-- Link para o arquivo de estilo principal -->
    <link rel="icon" href="../../Imagens/icone.svg" /> <!-- Ícone exibido na aba do navegador -->
  </head>

  <body>
    <!-- Barra lateral de navegação -->
    <div id="sidebar" class="taskbar">
      <div class="login">
        <!-- Link para a página de conta/perfil -->
        <div class="perfil" id="expandSidebar">
          <a href="../HTML/create.html">
            <img id="perfilIcon" src="../../Imagens/Perfil.svg" alt="Perfil" />
            <span>Conta</span>
          </a>
        </div>

        <!-- Link para a página de notificações -->
        <div class="sino">
          <a href="../HTML/notificacoes.html">
            <img src="../../Imagens/Sino.svg" alt="Notificações" />
          </a>
        </div>

        <!-- Link para a página de temas -->
        <div class="pincel" id="collapseSidebar">
          <a href="../HTML/temas.html">
            <img id="pincelIcon" src="../../Imagens/Pincel.svg" alt="Tema" />
          </a>
        </div>
      </div>

      <!-- Botão para adicionar nova tarefa -->
      <div class="addtask">
        <a href="../../index.php">
          <img src="../../Imagens/Mais.svg" alt="Adicionar Tarefa" />
          <span>Adicionar Tarefa</span>
        </a>
      </div>

      <!-- Navegação principal -->
      <div class="buttons">
        <!-- Link para página de tarefas -->
        <div class="calendario">
          <a href="tarefas.php">
            <img src="../../Imagens/Calendário.svg" alt="Minhas Tarefas" />
            <span>Minhas Tarefas</span>
          </a>
        </div>

        <!-- Link para tarefas concluídas -->
        <div class="concluido">
          <a href="concluidos.php">
            <img src="../../Imagens/Concluido.svg" alt="Concluídas" />
            <span>Concluído</span>
          </a>
        </div>
      </div>

      <hr /> <!-- Linha divisória -->

      <!-- Opções adicionais -->
      <div class="more">
        <!-- Link para adicionar membros à equipe -->
        <div class="equipe">
          <a href="../HTML/equipe.html">
            <img src="../../Imagens/Mais.svg" alt="Adicionar Equipe" />
            <span>Adicionar equipe</span>
          </a>
        </div>

        <!-- Link para configurações -->
        <div class="suporte">
          <a href="../HTML/config.html">
            <img src="../../Imagens/config.svg" alt="Configurações" />
            <span>Configurações</span>
          </a>
        </div>
      </div>
    </div>

    <!-- Conteúdo principal da página -->
    <div class="conteudo">
      <div class="logonot">
        <!-- Logo com link para a página inicial -->
        <a href="../../index.php">
          <img src="../../Imagens/logo.svg" alt="Logo" />
        </a>
      </div>

      <!-- Título da seção -->
      <h1 class="text-t">Tarefas em andamento:</h1>

      <div class="text-t">
        <?php foreach ($tarefas as $tarefa): ?>
            <?php if (!$tarefa['concluida']): ?>
                <li>
                    <strong><?php echo htmlspecialchars($tarefa['titulo']); ?></strong> -
                    <?php echo htmlspecialchars($tarefa['descricao']); ?><br>
                    <em><?php echo htmlspecialchars($tarefa['categoria']); ?> - <?php
                    $data_formatada = date('d/m/Y H:i', strtotime($tarefa['data']));
                    echo htmlspecialchars($data_formatada); ?></em><br>
                    [⏳ Pendente]
                    <a href="concluir.php?id=<?php echo $tarefa['id']; ?>">Concluir</a>
                    <a href="excluir.php?id=<?php echo $tarefa['id']; ?>">Excluir</a>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <!-- Script JavaScript da página -->
    <script src="../JS/scripts.js" defer></script>
  </body>
</html>
