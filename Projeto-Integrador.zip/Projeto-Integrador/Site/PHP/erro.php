<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Erro - Tarefy</title>
    <link rel="stylesheet" href="main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../Imagens/icone.svg">

</head>
<body>
    <div class="text-t">
        <h1>Opa! Algo deu errado...</h1>
        <p>Você precisa preencher todos os campos.</p>
        <a href="../../index.php"> Voltar</a>
    </div>
</body>
</html>