<?php
$arquivo = __DIR__ . '/../DADOS/tarefas.json'; // onde as informações são armazenadas

$id = $_GET['id'] ?? '';

$tarefas = json_decode(file_get_contents($arquivo), true);

$tarefas = array_filter($tarefas, fn($tarefa) => $tarefa['id'] !== $id);

file_put_contents($arquivo, json_encode(array_values($tarefas), JSON_PRETTY_PRINT));

header('Location: ../../index.php');
exit;
?>