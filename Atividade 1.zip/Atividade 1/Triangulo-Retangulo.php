<?php

$lado1 = ($_POST["lado1"]);
$lado2 = ($_POST["lado2"]);
$lado3 = ($_POST["lado3"]);
$lados = [$lado1, $lado2, $lado3];

if ($lado1 + $lado2 > $lado3 && $lado1 + $lado3 > $lado2 && $lado2 + $lado3 > $lado1) {
    if ((pow($lados[0], 2) + pow($lados[1], 2)) == (pow($lados[2], 2))) {
        print ("É um triângulo retângulo.");
    } else {
        print ("Não é um triângulo retângulo.");
    }
} else {
    print ("Os lados fornecidos não formam um triângulo.");
}
?>